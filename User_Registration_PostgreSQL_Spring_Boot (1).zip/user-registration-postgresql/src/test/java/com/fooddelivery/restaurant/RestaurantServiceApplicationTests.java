package com.fooddelivery.restaurant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestaurantServiceApplicationTests {

    @Test
    void applicationClassLoads() {
        // Context startup is verified by Spring Boot.
    }
}
