package com.fooddelivery.restaurant.dto;

public record RegisterUserResponse(
        Long id,
        String username,
        String email,
        String message
) {
}
