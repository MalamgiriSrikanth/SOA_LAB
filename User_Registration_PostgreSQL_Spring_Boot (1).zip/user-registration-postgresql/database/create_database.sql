-- Run this command while connected to the PostgreSQL server,
-- using a database other than ecommerce_db.
CREATE DATABASE ecommerce_db;
