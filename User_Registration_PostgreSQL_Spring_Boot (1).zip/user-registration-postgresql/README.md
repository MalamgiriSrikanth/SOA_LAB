# User Registration and PostgreSQL Persistence

Spring Boot 3.5.5 / Java 21 / Spring Data JPA / PostgreSQL / Swagger UI.

## 1. Prerequisites
- JDK 21
- Maven 3.6.3 or later (or Maven support in Spring Tool Suite)
- PostgreSQL running locally

## 2. Create the database
Run the SQL in `database/create_database.sql` from pgAdmin's Query Tool while connected to a different database (for example, `postgres`). Do not run `CREATE DATABASE` while connected to `ecommerce_db`.

Alternatively, create a database named `ecommerce_db` manually in pgAdmin.

## 3. Set database credentials
Open `src/main/resources/application.properties` and set `spring.datasource.username` and `spring.datasource.password` to your local PostgreSQL credentials.

The defaults are:
- Database: `ecommerce_db`
- Username: `postgres`
- Password: `postgres`

Change the password to match your installation. Alternatively, set environment variables `DB_URL`, `DB_USERNAME`, and `DB_PASSWORD`.

## 4. Import into Spring Tool Suite
1. Extract the ZIP.
2. Open STS.
3. Select **File > Import > Maven > Existing Maven Projects**.
4. Browse to the extracted `user-registration-postgresql` folder.
5. Select the project and click **Finish**.
6. Right-click the project > **Maven > Update Project**.
7. Confirm STS is using JDK 21: **Project > Properties > Java Compiler** and **Java Build Path**.

## 5. Run
Open `src/main/java/com/fooddelivery/restaurant/RestaurantServiceApplication.java`.
Right-click it > **Run As > Spring Boot App**.

Wait for the console to show that the application started. Ensure PostgreSQL is running and the credentials are correct.

## 6. Test with Swagger UI
Open: http://localhost:8080/swagger-ui/index.html

Expand `POST /api/users/register`, click **Try it out**, use this JSON, then click **Execute**:

```json
{
  "username": "srikanth",
  "email": "srikanth@example.com",
  "password": "TestPass123!"
}
```

Expected result: HTTP `201 Created`, with a response similar to:

```json
{
  "id": 1,
  "username": "srikanth",
  "email": "srikanth@example.com",
  "message": "User registered successfully"
}
```

The ID will vary. Reusing an email returns HTTP `409 Conflict`. Invalid input returns HTTP `400 Bad Request`.

## 7. Verify persistence
In pgAdmin, open the `ecommerce_db` database's Query Tool and run:

```sql
SELECT id, username, email, password FROM users;
```

The `users` table is created automatically by JPA when the application starts. The password column stores a BCrypt hash, not the plain-text password.

## API summary
- Method: `POST`
- Endpoint: `/api/users/register`
- Full URL: `http://localhost:8080/api/users/register`
- Content type: `application/json`

## Notes
- The project package is `com.fooddelivery.restaurant`.
- `spring.jpa.hibernate.ddl-auto=update` is convenient for this lab exercise. For production, use database migrations and stronger configuration management.
- This lab does not implement login/authentication.
